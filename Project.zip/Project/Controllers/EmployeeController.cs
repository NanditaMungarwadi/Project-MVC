﻿using Microsoft.AspNetCore.Mvc;
using Project.Models;

namespace Project.Controllers
{
    public class EmployeeController : Controller
    {
        private static List<Employee> employees = new List<Employee>
        {
            new Employee { Id = 1, Name = "Alice", Position = "Developer", Salary = 60000 },
            new Employee { Id = 2, Name = "Bob", Position = "Designer", Salary = 55000 },
            new Employee { Id = 3, Name = "Charlie", Position = "Manager", Salary = 75000 },
            new Employee {Id = 4, Name = "Drake",Position = " junior Developer" , Salary =35000},
            new Employee { Id = 5, Name = "Elara", Position = "Assistant", Salary = 25000 },
            new Employee {Id = 6, Name = "Genevra",Position = " Senior Developer" , Salary =85000},

        };
        public IActionResult Index()
        {
            return View(employees);
        }
        public IActionResult create() => View();
        [HttpPost]
        public IActionResult create(Employee employee)
        {
            employee.Id = employees.Count + 1;
            employees.Add(employee);
           return RedirectToAction("Index");
        }
        public IActionResult Edit(int id)
        {
            var employee = employees.FirstOrDefault(e => e.Id == id);
            if (employee == null) return NotFound();
            return View(employee);
        }
        [HttpPost]
        public IActionResult Edit(Employee employee)
        {
            var existingEmployee = employees.FirstOrDefault(e => e.Id == employee.Id);
            if (existingEmployee != null)
            {
                existingEmployee.Name = employee.Name;
                existingEmployee.Position = employee.Position;
                existingEmployee.Salary = employee.Salary;
            }
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var employee = employees.FirstOrDefault(e => e.Id == id);
            if (employee != null) employees.Remove(employee);
            return RedirectToAction("Index");
        }
    }

}

